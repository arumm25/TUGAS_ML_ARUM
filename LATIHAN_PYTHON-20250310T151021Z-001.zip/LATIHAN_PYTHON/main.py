
import latihan_package.alpha as a
import latihan_package.beta as b

a.alphaSatu()