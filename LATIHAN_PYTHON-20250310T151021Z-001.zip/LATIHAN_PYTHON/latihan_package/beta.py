def betaSatu():
	print("betaSatu")

def betaDua():
 print("betaDua")

#main.py
