def alphaSatu():
	print("alpha   Satu")

def alphaDua():
	print("alphaDua")